# main.py

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from config import TOKEN
from modules.logic import (
    handle_start, handle_profile, handle_train,
    handle_boost, handle_stats, handle_fortune, handle_noise
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    res = handle_start(update.effective_user.id, update.effective_user.first_name)
    await update.message.reply_text(res)

async def profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    res = handle_profile(update.effective_user.id, update.effective_user.first_name)
    await update.message.reply_text(res)

async def train(update: Update, context: ContextTypes.DEFAULT_TYPE):
    res = handle_train(update.effective_user.id, update.effective_user.first_name)
    await update.message.reply_text(res)

async def boost(update: Update, context: ContextTypes.DEFAULT_TYPE):
    res = handle_boost(update.effective_user.id, update.effective_user.first_name)
    await update.message.reply_text(res)

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    res = handle_stats(update.effective_user.id, update.effective_user.first_name)
    await update.message.reply_text(res)

async def fortune(update: Update, context: ContextTypes.DEFAULT_TYPE):
    res = handle_fortune()
    await update.message.reply_text(res)

async def noise(update: Update, context: ContextTypes.DEFAULT_TYPE):
    res = handle_noise()
    await update.message.reply_text(res)

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("profile", profile))
    app.add_handler(CommandHandler("train", train))
    app.add_handler(CommandHandler("boost", boost))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("fortune", fortune))
    app.add_handler(CommandHandler("noise", noise))
    print("QoreGPT запущено.")
    app.run_polling()

if __name__ == "__main__":
    main()
