# modules/profile.py

class Profile:
    def __init__(self, user_id, username):
        self.user_id = user_id
        self.username = username
        self.level = 1
        self.exp = 0
        self.hobbies = []
        self.skills = {
            'харизма': 1,
            'сила': 1,
            'креативність': 1
        }

    def add_hobby(self, hobby):
        if hobby not in self.hobbies:
            self.hobbies.append(hobby)

    def add_exp(self, amount):
        self.exp += amount
        if self.exp >= 100:
            self.exp -= 100
            self.level += 1
            return True
        return False

    def boost_skill(self, skill):
        if skill in self.skills:
            self.skills[skill] += 1

    def get_stats(self):
        stats = f"Рівень: {self.level}\nДосвід: {self.exp}\n"
        stats += "\n".join(f"{k.capitalize()}: {v}" for k, v in self.skills.items())
        return stats
