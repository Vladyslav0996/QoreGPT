# modules/logic.py

from modules.profile import Profile
from modules.hobbies import get_random_hobby
from modules.crafting import get_random_craft, add_custom_craft
import random
import json
import os

SAVE_FILE = "profiles.json"
users = {}

def load_profiles():
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            for uid, pdata in data.items():
                profile = Profile(pdata["user_id"], pdata["username"])
                profile.level = pdata["level"]
                profile.exp = pdata["exp"]
                profile.hobbies = pdata["hobbies"]
                profile.skills = pdata["skills"]
                users[int(uid)] = profile

def save_profiles():
    data = {
        uid: {
            "user_id": p.user_id,
            "username": p.username,
            "level": p.level,
            "exp": p.exp,
            "hobbies": p.hobbies,
            "skills": p.skills
        } for uid, p in users.items()
    }
    with open(SAVE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_or_create_profile(user_id, username):
    if user_id not in users:
        users[user_id] = Profile(user_id, username)
    return users[user_id]

def handle_start(user_id, username):
    get_or_create_profile(user_id, username)
    return f"Привіт, {username}! Я QoreGPT — твій AI-наставник."

def handle_profile(user_id, username):
    profile = get_or_create_profile(user_id, username)
    return f"👤 Профіль: {profile.username}\nРівень: {profile.level}\nДосвід: {profile.exp}\nХобі: {', '.join(profile.hobbies) or 'немає'}"

def handle_train(user_id, username):
    profile = get_or_create_profile(user_id, username)
    hobby = get_random_hobby()
    profile.add_hobby(hobby)
    level_up = profile.add_exp(50)
    save_profiles()
    msg = f"🎯 Ти тренував: {hobby} (+50 досвіду)"
    if level_up:
        msg += "\n🔥 Ти досягнув нового рівня!"
    return msg

def handle_boost(user_id, username):
    profile = get_or_create_profile(user_id, username)
    skill = random.choice(list(profile.skills.keys()))
    profile.boost_skill(skill)
    save_profiles()
    return f"💪 Ти прокачав навичку: {skill.capitalize()}!"

def handle_stats(user_id, username):
    profile = get_or_create_profile(user_id, username)
    return profile.get_stats()

def handle_fortune():
    phrases = [
        "Сьогодні твій день — діяй!",
        "Зупинись. Подихай. І руш далі.",
        "QoreGPT вірить у тебе!",
        "Навіть AI не знає, наскільки ти крутий.",
        "Успіх поруч. Просто зроби крок."
    ]
    return random.choice(phrases)

def handle_noise():
    noises = [
        "Бззз... Що? Хтось згадав ім'я QoreGPT?",
        "💥 Бум! Твій профіль оновився... чи ні?",
        "🚀 Генерую паралельну реальність...",
        "🌀 QoreGPT впав у шумовий транс..."
    ]
    return random.choice(noises)

def handle_craft():
    item = get_random_craft()
    return f"🔧 {item['title']}\n{item['description']}\n➡️ {item['effect']}"

def handle_add_craft(title, description, effect):
    add_custom_craft(title, description, effect)
    return f"✅ Додано нову самодєлку: {title}"
