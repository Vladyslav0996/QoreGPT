# modules/hobbies.py

HOBBIES = [
    'Парфумерія', 'Писанкарство', 'Геймінг', 'Фотографія', 'Кулінарія',
    'Астрономія', 'Танці', 'Музика', 'Медитація', 'Програмування'
]

def get_random_hobby():
    import random
    return random.choice(HOBBIES)
