# modules/crafting.py

CRAFTS = [
    {
        "title": "Фільтр для води з пляшки",
        "description": "Пластикова пляшка + пісок + вугілля = простий фільтр для очищення води.",
        "effect": "Дає +1 до навички виживання"
    },
    {
        "title": "Вогонь без сірників",
        "description": "Сухі гілки, мох і тертя деревини допоможуть розпалити вогонь у польових умовах.",
        "effect": "Збільшує шанс виживання в холодних умовах"
    }
]

def get_random_craft():
    import random
    return random.choice(CRAFTS)

def add_custom_craft(title, description, effect):
    CRAFTS.append({
        "title": title,
        "description": description,
        "effect": effect
    })
