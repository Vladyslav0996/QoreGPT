# SGPerfume main logic

def main():
    print('Ласкаво просимо до SGPerfume!')

if __name__ == '__main__':
    main()